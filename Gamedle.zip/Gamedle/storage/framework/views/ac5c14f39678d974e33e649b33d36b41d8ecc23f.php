<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>MOVIEDLE</title>

        <!-- Jquery -->
        <script src="/frames/jquery/jquery.min.js"></script>
        <script src="/frames/jquery/jquery-scroll/jquery.jscroll.min.js"></script>
        <script src="/frames/jquery/jquery-form/jquery.form.min.js"></script>

        <!--Bootstrap (5.2.1)-->
        <link rel="stylesheet" href="/frames/bootstrap-5.2.1/css/bootstrap.min.css">
        <script src="/frames/bootstrap-5.2.1/js/bootstrap.bundle.min.js"></script>

        <!--Selectize-->
        <script src="/frames/bootstrap-5.2.1/js/selectize.min.js"></script>
        <link rel="stylesheet" href="/frames/bootstrap-5.2.1/css/selectize.bootstrap3.min.css"/>

        <!--Ionicons-->
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

        <link rel="stylesheet" href="/css/style.css">

        <script src="/js/play.js"></script>
    </head>
    <body>
        
        <?php
            $daily_Movie = json_decode(Storage::get('public/jsons_game/dailys_movies.json'), true);
            if (array_key_exists(date('Y-m-d'), $daily_Movie)) {
                $daily_Movie = $daily_Movie[date('Y-m-d')];
            }
            else {
                App\Http\Controllers\GetsController::dailyMovie();
                return redirect('/');
            }

            $game = $infos->get('game_prin', null);

            $reset = explode(':', date('H:i:s', strtotime(date('Y-m-d 00:00:00', strtotime('+1 day'))) - strtotime(date('Y-m-d H:i:s'))));
        ?>

        <header class="d-flex justify-content-around navbar navbar-expand-sm bg-dark navbar-dark text-light">
            <div id="left_header">
                <h6 class="text-center">Próxima:<br>
                    <small id="timer">
                        <span id="hour"></span>
                        <span id="minute"></span>
                        <span id="seconds"></span>
                    </small>
                    <script>
                        var hours = parseInt('<?php echo $reset[0]; ?>');
                        var minutes = parseInt('<?php echo $reset[1]; ?>');
                        var seconds = parseInt('<?php echo $reset[2]; ?>');

                        document.getElementById('hour').innerHTML = '<?php echo $reset[0]; ?>:';
                        document.getElementById('minute').innerHTML = '<?php echo $reset[1]; ?>:';
                        document.getElementById('seconds').innerHTML = '<?php echo $reset[2]; ?>';
                        setInterval(function () {
                            if (seconds == 0) {
                                seconds = 59;
                                if (minutes == 0) {
                                    minutes = 59;
                                    hours--;
                                }
                                else{
                                    minutes--;
                                }

                            } else {
                                seconds--;
                            }
                            if (hours <= 0 && minutes <= 0 && seconds <= 0) {
                                location.reload();
                            }

                            hours_str = '' + hours;
                            hours_str = hours_str.padStart(2, '0');
                            minutes_str = '' + minutes;
                            minutes_str = minutes_str.padStart(2, '0');
                            seconds_str = '' + seconds;
                            seconds_str = seconds_str.padStart(2, '0');

                            document.getElementById('hour').innerHTML = hours_str + ':';
                            document.getElementById('minute').innerHTML = minutes_str + ':';
                            document.getElementById('seconds').innerHTML = seconds_str;
                        }, 1000);
                    </script>
                </h6>
            </div>
            <div id="center_header">
                <img src="/imgs/specials/coverdle_2.png" alt="MOVIEDLE" id="logo_header">
            </div>
            <div id="right_header">
                <ion-icon name="help-circle-outline" id="open_about"></ion-icon>
            </div>
        </header>

        <div id="about" class="container_absolute" style="display: none;">
            <div id="about_a" class="container-sm">
                <button type="button" class="btn-close" id="close_about"></button>
                <div class="topic_about d-flex align-items-center flex-column">
                    <h4 class="text-center">SOBRE:</h4>
                    <p>
                        Moviedle é um jogo feito para gamers, criado por um único desenvolvedor.
                        Inspirado em  <a class="a_about" href="https://www.gamedle.wtf/" target="_blank" rel="noopener noreferrer">Gamedle</a>, <a class="a_about" href="https://term.ooo/" target="_blank" rel="noopener noreferrer">Termo</a>  e outros.
                    </p>
                    <p>
                        Todos os direitos pertencem aos seus respectivos donos - sem nenhuma intenção de violar direitos autorais.
                        Logos são da  <a class="a_about" href="https://www.freepik.com/" target="_blank" rel="noopener noreferrer">Freepik</a>.
                    </p>
                    <p>
                        Utilizada API do <a class="a_about" href="https://www.themoviedb.org/" target="_blank" rel="noopener noreferrer">TMDB</a>
                    </p>
                    <img src="/imgs/specials/TMDB.svg" alt="TMDB" style="width: 250px;">
                </div>
                <hr>
                <div class="topic_about">
                    <h3 class="text-center">COMO JOGAR:</h3>
                    <p class="text-center">
                        Todos os dias uma nova capa de filme é apresentada e você precisa adivinhar em até 5 tentativas!
                        <br>
                        <br>
                        Cada tentativa incorreta fará com que uma parte adicional da imagem seja revelada.
                    </p>
                </div>
                <hr>
                <div class="topic_about">
                    <p class="text-center" style="font-weight: bold;">Developed By <span style="color: orange;">Nalo</span></p>
                </div>
            </div>
        </div>

        <main class="cont-principal">
            <section class="d-flex align-items-center flex-column">
                <!-- <div id="img_playing">
                    <canvas id="img_canva_play"></canvas>
                    <img id="img_to_canva_play" src="/imgs/teste.webp">
                </div> -->
                
                <?php if($game != null && $game['daily'] == date('Y-m-d') && $game['progress'] == 2): ?>
                    <div id="img_playing" class="not_finished_play">
                        <img id="img_to_canva_play" src="https://image.tmdb.org/t/p/original/<?php echo e($daily_Movie['poster_path']); ?>">
                        <div id="loading_img_play">
                            <div class="spinner-grow text-warning"></div>
                        </div>
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <?php if(in_array($i - 1, $game['revealed_prin'])): ?>
                                <div id="cont-img-play-<?php echo e($i); ?>" class="cont-img-play-show"></div>
                            <?php else: ?>
                                <div id="cont-img-play-<?php echo e($i); ?>" class="cont-img-play"></div>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <div id="lifes_to_play">
                        <?php
                            $hearts = $game['hearts'];
                        ?>
                        <?php for($i = 0; $i < 5; $i++): ?>
                            <?php if($hearts > 0): ?>
                                <ion-icon name="heart"></ion-icon>
                                <?php
                                    $hearts--;
                                ?>
                            <?php else: ?>
                                <ion-icon name="heart-outline"></ion-icon>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <form class="form-response" id="n_principal" action="/t_daily">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="resps" value="<?php echo e(base64_encode($daily_Movie['id']) . ',' . base64_encode($daily_Movie['title'])); ?>">
                        <input type="hidden" name="movies_chooses" id="movies_chooses">
                        <div id="resp_movies">
                            <select class="form-control" name="movies_c" id="movies">
                            </select>
                        </div>
                        <button type="button" id="to_play" class="btn btn-primary mt-2">Adivinhar!</button>
                    </form>
                <?php elseif($game != null && $game['daily'] == date('Y-m-d') && $game['progress'] == 0 || $game != null && $game['daily'] == date('Y-m-d') && $game['progress'] == 1): ?>
                    <div id="img_playing" class="finished_play <?php echo e($game['progress'] ? 'b-linear-danger' : 'b-linear-primary'); ?>">
                        <img id="img_to_canva_play" src="https://image.tmdb.org/t/p/original/<?php echo e($daily_Movie['poster_path']); ?>">
                        <div id="loading_img_play">
                            <div class="spinner-grow text-warning"></div>
                        </div>
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <div id="cont-img-play-<?php echo e($i); ?>" class="cont-img-play-show"></div>
                        <?php endfor; ?>
                    </div>
                    <div id="informations_movie">
                        <h3 class="text-center mt-2 mb-0" style="font-weight: bold;"><?php echo e($daily_Movie['title']); ?></h3>
                        <p class="text-center m-0">(<?php echo e(date('Y', strtotime($daily_Movie['release_date']))); ?>)</p>
                    </div>
                    <a href="/unlimited" class="btn_1 mt-2">MODO ILIMITADO</a>
                <?php else: ?>
                    <div id="img_playing" class="not_finished_play">
                            <img id="img_to_canva_play" src="https://image.tmdb.org/t/p/original/<?php echo e($daily_Movie['poster_path']); ?>">
                            <div id="loading_img_play">
                                <div class="spinner-grow text-warning"></div>
                            </div>
                        <?php
                            $to_show = random_int(0, 5);
                            $infos
                            ->put(
                                'game_prin', 
                                array(
                                    'daily' => date('Y-m-d'),
                                    'revealed_prin' => array($to_show), 
                                    'hearts' => 5,
                                    'progress' => 2
                                )
                            );
                        ?>
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <?php if($i - 1 == $to_show): ?>
                                <div id="cont-img-play-<?php echo e($i); ?>" class="cont-img-play-show"></div>
                            <?php else: ?>
                                <div id="cont-img-play-<?php echo e($i); ?>" class="cont-img-play"></div>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <div id="lifes_to_play">
                        <ion-icon name="heart"></ion-icon>
                        <ion-icon name="heart"></ion-icon>
                        <ion-icon name="heart"></ion-icon>
                        <ion-icon name="heart"></ion-icon>
                        <ion-icon name="heart"></ion-icon>
                    </div>
                    <form class="form-response" id="n_principal" action="/t_daily">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="resps" value="<?php echo e(base64_encode($daily_Movie['id']) . ',' . base64_encode($daily_Movie['title'])); ?>">
                        <input type="hidden" name="movies_chooses" id="movies_chooses">
                        <div id="resp_movies">
                            <select class="form-control" name="movies_c" id="movies">
                            </select>
                        </div>
                        <button type="button" id="to_play" class="btn btn-primary mt-2">Adivinhar!</button>
                    </form>
                <?php endif; ?>
                
            </section>
        </main>

    </body>
</html>
<?php /**PATH C:\Users\cs044\OneDrive\Documentos\Projects\cover_dle\resources\views/welcome.blade.php ENDPATH**/ ?>