<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

use App\Http\Controllers\GetsController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $infos = \Request::session();
    return view('welcome', ['infos' => $infos]);
});
Route::match(['GET', 'POST'], '/unlimited', [UserController::class, 'UnlimitedMode']);

Route::match(['GET', 'POST'], '/g/movies-list', [GetsController::class, 'searchMovie']);
Route::match(['GET', 'POST'], '/movie/daily', [GetsController::class, 'dailyMovie']);

Route::match(['GET', 'POST'], '/t_daily', [UserController::class, 'DailyResponse']);
Route::match(['GET', 'POST'], '/t_unlimited', [UserController::class, 'UnlimitedResponse']);
Route::match(['GET', 'POST'], '/g_next', [GetsController::class, 'NextUnlimitedMode']);
