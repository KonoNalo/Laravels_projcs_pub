$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

movies_select = null;
// game = JSON.parse(getCookie('game'));

// window.onload = function() {
//     // var playing = document.getElementById('img_playing');
//     // var img = document.getElementById("img_to_canva_play");
//     // playing.style.width = img.offsetWidth + 'px';
//     // playing.style.height = img.offsetHeight + 'px';
//     // playing.style.backgroundImage = 'url("' + img.src + '")';
//     // console.log(img.src);
//     // img.remove();

//     var canvas = document.getElementById("img_canva_play");
//     var ctx = canvas.getContext("2d");
//     var img = document.getElementById("img_to_canva_play");
//     canvas.width = img.offsetWidth;
//     canvas.height = img.offsetHeight;
//     ctx.drawImage(img, 0, 0, img.offsetWidth, img.offsetHeight);
//     img.remove();

//     var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
//     console.log(imageData);
// };

function to_play() {

    formS = document.getElementById('n_principal');
    $.ajax({
        url: formS.action,
        type: "post",
        data: $('#n_principal').serialize(),
        success: function (res) {
            console.log(res);
            if (res.response == 226) {
                document.getElementById('cont-img-play-' + (res.to_show + 1)).classList = 'cont-img-play-show';
                var all_lifes = document.querySelectorAll('#lifes_to_play > ion-icon[name="heart"]');
                all_lifes[all_lifes.length - 1].setAttribute('name', 'heart-outline');
            }
            else if(res.response == 418 && res.result == 1 || res.response == 200 && res.result == 0){
                var movie_atual = res.list_atual;
                var all_blocks = document.getElementsByClassName('cont-img-play');
                while (all_blocks.length > 0) {
                    console.log(all_blocks[0]);
                    all_blocks[0].setAttribute('class', 'cont-img-play-show');
                    all_blocks = document.getElementsByClassName('cont-img-play');
                }
                // var playing = document.getElementById('img_playing');
                // playing.classList = 'finished_play';
                playing = res.result ? 'b-linear-danger' : 'b-linear-primary';
                document.getElementById('img_playing').setAttribute('class', 'finished_play ' + playing)

                document.getElementById('lifes_to_play').remove();
                document.getElementById('n_principal').remove();
                year_movie = new Date(movie_atual['release_date']);  
                document.getElementById('img_playing').insertAdjacentHTML('afterend',
                `
                    <div id="informations_movie">
                        <h3 class="text-center mb-0" style="font-weight: bold;">` + movie_atual['title'] + `</h3>
                        <p class="text-center m-0">(` + year_movie.getFullYear() + `)</p>
                    </div>
                    <a href="/unlimited" class="btn_1 mt-2">MODO ILIMITADO</a>
                `);
            }
        },
        error: function (jqXHR) {
            console.log(jqXHR);
            if (jqXHR.status != '418') {
                location.reload();
            }
        },
    });
}
function to_play_unlimited() {

    formS = document.getElementById('n_principal');
    $.ajax({
        url: formS.action,
        type: "post",
        data: $('#n_principal').serialize(),
        success: function (res) {
            console.log(res);
            if (res.response == 226) {
                document.getElementById('cont-img-play-' + (res.to_show + 1)).classList = 'cont-img-play-show';
                var all_lifes = document.querySelectorAll('#lifes_to_play > ion-icon[name="heart"]');
                all_lifes[all_lifes.length - 1].setAttribute('name', 'heart-outline');
            }
            else if(res.response == 418 && res.result == 1 || res.response == 200 && res.result == 0){
                var movie_atual = res.list_atual;
                var all_blocks = document.getElementsByClassName('cont-img-play');
                while (all_blocks.length > 0) {
                    console.log(all_blocks[0]);
                    all_blocks[0].setAttribute('class', 'cont-img-play-show');
                    all_blocks = document.getElementsByClassName('cont-img-play');
                }
                // var playing = document.getElementById('img_playing');
                // playing.classList = 'finished_play';
                playing = res.result ? 'b-linear-danger' : 'b-linear-primary';
                document.getElementById('img_playing').setAttribute('class', 'finished_play ' + playing)

                document.getElementById('lifes_to_play').remove();
                document.getElementById('n_principal').remove();
                year_movie = new Date(movie_atual['release_date']);  
                document.getElementById('img_playing').insertAdjacentHTML('afterend',
                `
                    <div id="informations_movie">
                        <h3 class="text-center mb-0" style="font-weight: bold;">` + movie_atual['title'] + `</h3>
                        <p class="text-center m-0">(` + year_movie.getFullYear() + `)</p>
                    </div>
                `);

               
                document.getElementById('next_game').style.display = 'block';
                document.getElementById('current_sequence').innerHTML = res.game['current_sequence'];
                document.getElementById('top_sequence').innerHTML = res.game['top_sequence'];
            }
        },
        error: function (jqXHR) {
            console.log(jqXHR);
            if (jqXHR.status != '418') {
                location.reload();
            }
        },
    });
}

function next_game_unlimited() {
    $.ajax({
        url: '/g_next',
        type: "post",
        beforeSend: function (jqXHR) {
            document.getElementById('loading_img_play').style.display = 'flex';
        },
        success: function (res) {
            console.log(res);
            document.getElementById('next_game').style.display = 'none';
            var blocks = [];
            for (let i = 1; i <= 6; i++) {
                if(res.game['revealed_prin'].includes(i - 1)){
                    blocks.push('<div id="cont-img-play-' + i + '" class="cont-img-play-show"></div>');
                }
                else{
                    blocks.push('<div id="cont-img-play-' + i + '" class="cont-img-play"></div>');
                }
            }
            var playing = document.getElementById('img_playing');
            playing.innerHTML = 
            `
                <img id="img_to_canva_play" src="https://image.tmdb.org/t/p/original/` + res.game['current_game']['poster_path'] + `">
                <div id="loading_img_play">
                    <div class="spinner-grow text-warning"></div>
                </div>
                `
                + blocks.join('') +
                `
            `
            var img = document.getElementById("img_to_canva_play");
            img.onload = function(){
                document.getElementById('loading_img_play').style.display = 'none';
                playing.style.width = img.offsetWidth + 'px';
                playing.style.height = img.offsetHeight + 'px';
                playing.style.backgroundImage = 'url("' + img.src + '")';
                img.remove();
            };

            var hearts = res.game['hearts'];
            var lifes = [];
            for (let i = 0; i < 5; i++) {
                if(hearts > 0){
                    lifes.push('<ion-icon name="heart"></ion-icon>');
                    hearts--;
                }
                else{
                    lifes.push('<ion-icon name="heart-outline"></ion-icon>');
                }
            }
            
            playing.insertAdjacentHTML('afterend', `
                <div id="lifes_to_play">
                    ` + lifes.join('') + `
                </div>
                <form class="form-response" id="n_principal" action="/t_unlimited">
                    <input type="hidden" name="_token" value="` + $('meta[name="csrf-token"]').attr('content') + `">
                    <input type="hidden" name="movies_chooses" id="movies_chooses">
                    <div id="resp_movies">
                        <select class="form-control" name="movies_c" id="movies">
                        </select>
                    </div>
                    <button type="button" id="to_play_unlimited" class="btn btn-primary mt-2">Adivinhar!</button>
                </form>
            `);

            movies_select = $('#movies').selectize({
                sortField: 'text'
            });

            document.getElementById('next_game').addEventListener('click', next_game_unlimited, false);
            
            if (document.getElementById('movies-selectized') != null) {
                document.getElementById('movies-selectized').addEventListener('keyup', search_movies, false);
            }
            
            if (document.getElementById('to_play_unlimited') != null) {
                document.getElementById('to_play_unlimited').addEventListener('click', to_play_unlimited, false);
            }

            if (document.getElementById('informations_movie') != null) {
                document.getElementById('informations_movie').remove();
            }
        },
        error: function (jqXHR) {
            if (jqXHR.status != '418') {
                location.reload();
            }
        },
    });
}

// function search_movies() {
//     clearTimeout(this.interval);
//     this.interval = setTimeout(function () {
//         var lista = document.getElementById('movies');
//         var to_query = document.getElementById('movies_chooses').value;
//         var search = [];
//         for (let i = 0; i < lista.children.length; i++) {
//             search.push(lista.children[i].getAttribute('value'));
//         }
//         $.ajax({
//             url: '/g/movies-list',
//             type: "post",
//             data:{
//                 "search": search,
//                 "to_query": to_query
//             },
//             success: function (res) {
//                 for (let i = 0; i < res.movies.length; i++) {
//                     var atual_m = res.movies[i];
//                     if (search.indexOf(atual_m.id.toString()) < 0) {
//                         lista.insertAdjacentHTML('beforeend', '<option class="movies_in_list" value="' + atual_m.id + '" label="' + atual_m.title + '"></option>');
//                     }
//                 }
//             },
//             error: function (jqXHR) {
//                 // alert('Ocorreu um erro!')
//                 // location.reload();
//             },
//         });
//     }, 800);
// }

function search_movies() {
    document.getElementById('movies_chooses').value = document.getElementById('movies-selectized').value;
    clearTimeout(this.interval);
    this.interval = setTimeout(function () {
        var lista = document.getElementById('movies');
        var in_lista = document.getElementById('movies');
        var to_query = document.getElementById('movies_chooses').value;
        // var to_query = document.getElementById('movies-selectized').value;
        var load_search = document.getElementById('load-search-movies');
        var search = [];
        for (let i = 0; i < in_lista.children.length; i++) {
            search.push(in_lista.children[i].getAttribute('data-value'));
        }
        $.ajax({
            url: '/g/movies-list',
            type: "post",
            data: {
                "search": search,
                "to_query": to_query
            },
            beforeSend: function () {
                load_search.style.display = 'inline-block';
            },
            success: function (res) {
                if (res.movies != null) {
                    for (let i = 0; i < res.movies.length; i++) {
                        var atual_m = res.movies[i];
                        year_movie = new Date(atual_m['release_date']); 
                        if (search.indexOf(atual_m.id.toString()) < 0) {
                            //lista.insertAdjacentHTML('beforeend', '<option value="' + atual_m.id + '" label="' + atual_m.title + '"></option>');
                            var madd = movies_select[0].selectize;
                            madd.addOption({ value: atual_m.id, text: atual_m.title + '(' + year_movie.getFullYear() + ')' });
                            madd.refreshOptions();
                        }
                    }
                }
                load_search.style.display = 'none';
            },
            error: function (jqXHR) {
                alert('Ocorreu um erro!');
                location.reload();
            },
        });
    }, 800);
}

//About
function view_about() {
    var about = document.getElementById('about');
    if (about.style.display != "none") {
        about.style.display = "none";
    } 
    else {
        about.style.display = "flex";
    }
}

window.onload = function () {
    var playing = document.getElementById('img_playing');
    var img = document.getElementById("img_to_canva_play");
    playing.style.width = img.offsetWidth + 'px';
    playing.style.height = img.offsetHeight + 'px';
    playing.style.backgroundImage = 'url("' + img.src + '")';
    img.remove();

    //Jogo Principal
    // if (game == null || game['game_prin'] == null) {
    //     const d = new Date();
    //     d.setHours('21');
    //     d.setMinutes('00');
    //     d.setSeconds('00')
    //     d.setTime(d.getTime() + (24 * 60 * 60 * 1000));
    //     console.log(d.toUTCString());
    //     let to_show = Math.floor(Math.random() * 6);
    //     document.getElementById('cont-img-play-' + (to_show + 1)).classList = 'cont-img-play-show';

    //     if (game == null) {
    //         game =
    //         {
    //             "game_prin": {
    //                 "revealed_prin": [to_show],
    //                 "hearts": 6
    //             }
    //         };
    //     } else {
    //         game["game_prin"] =
    //         {
    //             "revealed_prin": [to_show],
    //             "hearts": 6
    //         }
    //     }

    //     setCookie('game', JSON.stringify(game), d.toUTCString());
    // }

    movies_select = $('#movies').selectize({
        sortField: 'text'
    });

    if (document.getElementById('img_to_canva_play') == null) {
        document.getElementById('loading_img_play').style.display = 'none';
    }

    document.getElementById('close_about').addEventListener('click', view_about, false);
    document.getElementById('open_about').addEventListener('click', view_about, false);
    if (document.getElementById('next_game') != null) {
        document.getElementById('next_game').addEventListener('click', next_game_unlimited, false);
    }
    

    if (document.getElementById('to_play') != null) {
        document.getElementById('to_play').addEventListener('click', to_play, false);
    }
    
    if (document.getElementById('movies-selectized') != null) {
        document.getElementById('movies-selectized').addEventListener('keyup', search_movies, false);
    }
    
    if (document.getElementById('to_play_unlimited') != null) {
        document.getElementById('to_play_unlimited').addEventListener('click', to_play_unlimited, false);
    }
};

function utf8_to_b64(str) {
    return window.btoa(unescape(encodeURIComponent(str)));
}

function b64_to_utf8(str) {
    return decodeURIComponent(escape(window.atob(str)));
}

/*! Caso queira utilizar Cookies ao invés do Session*/
// function getCookie(m_cookie, default_r = null) {
//     var cookieArr = document.cookie.split(";");
//     for (var i = 0; i < cookieArr.length; i++) {
//         var cookiePair = cookieArr[i].split("=");
//         if (m_cookie == cookiePair[0].trim()) {
//             return b64_to_utf8(decodeURIComponent(cookiePair[1]));
//         }
//     }

//     if (default_r != null) {
//         return default_r;
//     }
//     else {
//         return null;
//     }
// }

// function setCookie(cname, cvalue, time = null, exdays = null, to_path = null) {

//     if (time != null) {
//         var expires = "expires=" + time;
//     }
//     else {
//         const d = new Date();
//         d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
//         var expires = "expires=" + d.toUTCString();
//     }

//     if (to_path != null) {
//         var path = "path=" + to_path;
//     }
//     else {
//         var path = "path=/";
//     }

//     document.cookie = cname + "=" + utf8_to_b64(cvalue) + ";" + expires + ";" + path;
// }