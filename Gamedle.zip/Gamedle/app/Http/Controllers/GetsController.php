<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class GetsController extends Controller
{
    static $keyTMDB = '2bb2dee988754f4eeba86a519c5b1104';
    //2457
    public function searchMovie(Request $Request)
    {
        $keyTMDB = self::$keyTMDB;

        try {
            //$to_query = preg_replace('/(\s+)/', '+', $Request->input('to_query'));
            $to_query = urlencode($Request->input('to_query'));
            $list = json_decode(file_get_contents('https://api.themoviedb.org/3/search/movie?api_key=' . $keyTMDB . '&language=pt-BR&query=' . $to_query . '&page=1'), true);

            return response()->json(['movies' => $list['results']]);
        } catch (\Throwable $th) {
            return false;
        }
    }
    public static function dailyMovie(Request $Request = null)
    {
        $keyTMDB = self::$keyTMDB;
        $valid_movie = False;

        while (!$valid_movie) {
            $page_r = random_int(1, 250);
            $list = file_get_contents('https://api.themoviedb.org/3/movie/top_rated?api_key=' . $keyTMDB . '&language=pt-BR&page=' . $page_r);
            $movie_chosen = json_decode($list, true)['results'];
            $movie_chosen = $movie_chosen[random_int(0, count($movie_chosen) - 1)];
            $movie_chosen = json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $movie_chosen['id'] . '?api_key=' . $keyTMDB . '&language=pt-BR'), true);
            $alternative_title = array('alternative_titles' => json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $movie_chosen['id'] . '/alternative_titles?api_key=' . $keyTMDB), true)['titles']);
            $movie_chosen = array_merge($movie_chosen, $alternative_title);
            $to_save = array(date('Y-m-d') => $movie_chosen);
            $valid_movie = GetsController::validateMovie($to_save, 0);
        }

        if (Storage::exists('public/jsons_game/dailys_movies.json')) {
            $list_atual = json_decode(Storage::get('public/jsons_game/dailys_movies.json'), true);
            if (array_key_exists(date('Y-m-d'), $list_atual) && $Request->passw_ad == null) {
                abort('404');
            }
            $list_atual = array_merge($list_atual, $to_save);
            Storage::put('public/jsons_game/dailys_movies.json', json_encode($list_atual, JSON_UNESCAPED_UNICODE));
        }
        else {
            Storage::put('public/jsons_game/dailys_movies.json', json_encode($to_save, JSON_UNESCAPED_UNICODE));
        }
    }
    public function NextUnlimitedMode(Request $Request)
    {
        $keyTMDB = self::$keyTMDB;
        $infos = $Request->session();
        $game = $infos->get('game_unlimited', null);
        if ($game == null || $game['progress'] != 2) {
            $valid_movie = False;
            while (!$valid_movie) {
                $page_r = random_int(1, 250);
                $list = file_get_contents('https://api.themoviedb.org/3/movie/top_rated?api_key=' . $keyTMDB . '&language=pt-BR&page=' . $page_r);
                $current_game = json_decode($list, true)['results'];
                $current_game = $current_game[random_int(0, count($current_game) - 1)];
                $current_game = json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $current_game['id'] . '?api_key=' . $keyTMDB . '&language=pt-BR'), true);
                $valid_movie = GetsController::validateMovie($current_game, 1);
            }
            $alternative_title = array('alternative_titles' => json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $current_game['id'] . '/alternative_titles?api_key=' . $keyTMDB), true)['titles']);
            $current_game = array_merge($current_game, $alternative_title);

            $to_show = random_int(0, 5);
            if ($game == null) {
                $game = array(
                    'current_game' => $current_game,
                    'revealed_prin' => array($to_show), 
                    'hearts' => 5,
                    'progress' => 2,
                    'current_sequence' => 0,
                    'top_sequence' => 0,
                );
            }
            else {
                $game['current_game'] = $current_game;
                $game['revealed_prin'] = array($to_show);
                $game['hearts'] = 5;
                $game['progress'] = 2;
            }
            

            $infos
            ->put(
                'game_unlimited', 
                $game
            );
        }

        return response()->json(['game' => $game]);
    }

    public static function validateMovie($Movie, $Mode)
    {
        $banned_langs = ['ko', 'en', 'ru'];
        if ($Mode == 0) {
            try {
                if (in_array($Movie[date('Y-m-d')]['original_language'], $banned_langs) || $Movie[date('Y-m-d')]['poster_path'] == null) {
                    return false;
                }
        
                return true;
            } catch (\Throwable $th) {
                return false;
            }
        }
        else {
            try {
                if (in_array($Movie['original_language'], $banned_langs) || $Movie['poster_path'] == null) {
                    return false;
                }
        
                return true;
            } catch (\Throwable $th) {
                return false;
            }
        }
    }
}
