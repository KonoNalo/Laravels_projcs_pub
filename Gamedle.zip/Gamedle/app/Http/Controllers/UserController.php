<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    static $keyTMDB = 'YOUR_API_KEY';

    public function DailyResponse(Request $Request)
    {
        $keyTMDB = self::$keyTMDB;
        $list_atual = json_decode(Storage::get('public/jsons_game/dailys_movies.json'), true);
        if (!array_key_exists(date('Y-m-d'), $list_atual)) {
            abort('404');
        }

        $list_atual = $list_atual[date('Y-m-d')];
        
        $alternatives = $list_atual['alternative_titles'];
        $titles = array();
        foreach ($alternatives as $key => $a_title) {
            array_push($titles, $a_title['title']);
        }

        try {
            $alternatives = json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $Request->input('movies_c') . '?api_key=' . $keyTMDB . '&language=pt-BR'), true);
        } catch (\Throwable $th) {
            $alternatives = null;
        }

        $game = $Request->session()->get('game_prin', null);

        if ($game != null && $game['hearts'] > 0 && $game['progress'] == 2 && $Request->input('movies_c') == $list_atual['id'] ||
            $game != null && $game['hearts'] > 0 && $game['progress'] == 2 && $alternatives != null && in_array($alternatives['title'], $titles)) {
            $game['progress'] = 0;
            $Request->session()->put('game_prin', $game);
            return response()->json(['response' => 200, 'result' => 0, 'list_atual' => $list_atual]);
        } else {
            $to_show = array_rand(array_diff(range(0, 5), $game['revealed_prin']), 1);
            if ($game['hearts'] > 1) {
                $game['hearts']--;
                array_push($game['revealed_prin'], $to_show);
                $Request->session()->put('game_prin', $game);

                return response()->json(['response' => 226, 'to_show' => $to_show, 'all_infos' => $Request->all()]);
            }
            else {
                $game['progress'] = 1;
                $Request->session()->put('game_prin', $game);
                return response()->json(['response' => 418, 'to_show' => $to_show, 'result' => 1, 'list_atual' => $list_atual]);
            }
            //abort('226');
            //abort('418');
        }
        
    }

    public function UnlimitedMode(Request $Request)
    {
        $keyTMDB = self::$keyTMDB;
        $infos = $Request->session();
        $game = $infos->get('game_unlimited', null);
        if ($game == null || $game['progress'] != 2) {
            $valid_movie = False;
            while (!$valid_movie) {
                $page_r = random_int(1, 250);
                $list = file_get_contents('https://api.themoviedb.org/3/movie/top_rated?api_key=' . $keyTMDB . '&language=pt-BR&page=' . $page_r);
                $current_game = json_decode($list, true)['results'];
                $current_game = $current_game[random_int(0, count($current_game) - 1)];
                $current_game = json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $current_game['id'] . '?api_key=' . $keyTMDB . '&language=pt-BR'), true);
                $valid_movie = GetsController::validateMovie($current_game, 1);
            }
            $alternative_title = array('alternative_titles' => json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $current_game['id'] . '/alternative_titles?api_key=' . $keyTMDB), true)['titles']);
            $current_game = array_merge($current_game, $alternative_title);

            $to_show = random_int(0, 5);
            if ($game == null) {
                $game = array(
                    'current_game' => $current_game,
                    'revealed_prin' => array($to_show), 
                    'hearts' => 5,
                    'progress' => 2,
                    'current_sequence' => 0,
                    'top_sequence' => 0,
                );
            }
            else {
                $game['current_game'] = $current_game;
                $game['revealed_prin'] = array($to_show);
                $game['hearts'] = 5;
                $game['progress'] = 2;
            }
            

            $infos
            ->put(
                'game_unlimited', 
                $game
            );
        }
        return view('unlimited', ['infos' => $infos, 'game' => $game]);
    }
    public function UnlimitedResponse(Request $Request)
    {
        $keyTMDB = self::$keyTMDB;
        $game = $Request->session()->get('game_unlimited', null);
        if ($game != null) {
            $current_game = $game['current_game'];

            $alternatives = $current_game['alternative_titles'];
            $titles = array();
            foreach ($alternatives as $key => $a_title) {
                array_push($titles, $a_title['title']);
            }

            try {
                $alternatives = json_decode(file_get_contents('https://api.themoviedb.org/3/movie/' . $Request->input('movies_c') . '?api_key=' . $keyTMDB . '&language=pt-BR'), true);
            } catch (\Throwable $th) {
                $alternatives = null;
            }

            if ($game['hearts'] > 0 && $game['progress'] == 2 && $Request->input('movies_c') == $current_game['id'] ||
                $game['hearts'] > 0 && $game['progress'] == 2 && $alternatives != null && in_array($alternatives['title'], $titles)) {
                $game['progress'] = 0;
                $game['current_sequence']++;
                if ($game['current_sequence'] > $game['top_sequence']) {
                    $game['top_sequence'] = $game['current_sequence'];
                }
                $Request->session()->put('game_unlimited', $game);
                return response()->json(['response' => 200, 'result' => 0, 'game' => $game, 'list_atual' => $current_game]);
            } else {
                $to_show = array_rand(array_diff(range(0, 5), $game['revealed_prin']), 1);
                if ($game['hearts'] > 1) {
                    $game['hearts']--;
                    array_push($game['revealed_prin'], $to_show);
                    $Request->session()->put('game_unlimited', $game);

                    return response()->json(['response' => 226, 'to_show' => $to_show, 'all_infos' => $Request->all()]);
                }
                else {
                    $game['progress'] = 1;
                    if ($game['current_sequence'] > $game['top_sequence']) {
                        $game['top_sequence'] = $game['current_sequence'];
                    }
                    $game['current_sequence'] = 0;
                    $Request->session()->put('game_unlimited', $game);
                    return response()->json(['response' => 418, 'to_show' => $to_show, 'result' => 1, 'game' => $game, 'list_atual' => $current_game]);
                }
            }
        }
        else {
            abort('418');
        }
        
    }
    
}
